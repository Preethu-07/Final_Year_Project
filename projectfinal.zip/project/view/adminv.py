import random
from flask import url_for, render_template, request, session,redirect,jsonify
from winotify import Notification

from model import userm,adminm

def login():
    if request.method=='POST':
        adminname= request.form['adminname']
        password= request.form['password']
        if adminname=='main' and password=='123':
            session['adminname']=adminname
            return redirect(url_for('user.admin'))
        else:
            toast = Notification(app_id=" ",
                                     title="Message",
                                     msg="invalide creadential",
                                     duration="short"
                                     )
            toast.show()
            return render_template('admin/adminlogin.html')
    elif request.method=='GET':
        return render_template('admin/adminlogin.html')
    return render_template('user/index.html')

def adminhome():
    if 'adminname' in session:
        return render_template('admin/admin.html')
    else:
        return redirect(url_for('user.login'))

def users():
    if 'adminname' in session:
        usersList = adminm.getUsers()
        if request.method=='POST':
            item=request.form['item_id']
            user=userm.checkuser(item)
            item_id=adminm.checkuser(item)
            if user :
                adminm.deleteuser(item)
                toast = Notification(app_id=" ",
                                        title="Message",
                                        msg="Candidate details deleted Sucessfully",
                                        duration="short"
                                        )
                toast.show()
            elif item_id:
                verify='true'
                voter=adminm.checkvoter_Id(item,verify)
                if voter:
                    return redirect(url_for('user.users'))
                else:
                    voter_id=random.randint(1111,99999)
                    adminm.updateuser(item,str(voter_id),verify)
                    return redirect(url_for('user.users'))
                    
        return render_template('admin/usersList.html',usersList=usersList)
    else:
        return redirect(url_for('user.login'))

def result():
    if 'adminname' in session:
        votes= adminm.result()
        return render_template('admin/result.html' , votes=votes)
    else:
        return redirect(url_for('user.login'))
    
def correction():
    if 'adminname' in session:
        if request.method=='POST':
            user=request.form['user']
            if user=='update':
                user=request.form['name']
                address=request.form['address']
                state=request.form['state']
                email=request.form['email']
                phonenumber=request.form['phone']
                adminm.update_user(user,address,state,email,phonenumber)
                return redirect(url_for('user.correction'))
            else:
                userlist= userm.checkuser(user)
                return render_template('admin/update.html',userlist=userlist)
        elif request.method=='GET':
            userlist=adminm.check_voter_id()
            return render_template('admin/correction.html', userlist=userlist)
    else:
        return redirect(url_for('user.login'))
        
def logouta():
    session.pop('adminname', None)
    return redirect(url_for('user.index'))




