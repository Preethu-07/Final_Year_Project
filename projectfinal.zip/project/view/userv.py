from io import BytesIO
import bson
import random,smtplib
from email.message import EmailMessage
from flask import send_file, url_for, render_template, request, session,redirect
from winotify import Notification
from model import userm

otp=""
for i in range(6):
    otp+=str(random.randint(0,9))

server=smtplib.SMTP('smtp.gmail.com',587)
server.starttls()

from_mail='dhanush3855dhanu@gmail.com'
server.login(from_mail,'bvjw rggu msuz koxr')


def index():
    return render_template('user/index.html')

def aboutUs():
    return render_template('user/aboutUs.html')

def register():
    if request.method == 'POST':
        username = request.form['username']
        Address = request.form['Address']
        state = request.form['state']
        photo_file = request.files['photo']  # Updated to handle file input
        photo_binary = bson.Binary(photo_file.read())  # Convert to binary
        email = request.form['email']
        phonenumber=request.form['phonenumber']
        password = request.form['password']
        user=userm.checkuser(username)
        
        if user:
            toast = Notification(app_id=" ",
                                     title="Message",
                                     msg="user already exist",
                                     duration="short"
                                     )
            toast.show()
            return redirect(url_for('user.loginc'))
        else:
            userm.insertuser(username,Address,state,photo_binary,email,phonenumber,password)
            return redirect(url_for('user.loginc'))
    return render_template('user/register.html')

def loginr():
    if request.method=='POST':
        username= request.form['username']
        password= request.form['password']
        user= userm.checklogin(username , password)
        if user:
            session['username']=username
            toast = Notification(app_id=" ",
                                     title="Message",
                                     msg="login successful",
                                     duration="short"
                                     )
            toast.show()
            return redirect(url_for('user.voterdetails'))
        else:
            toast = Notification(app_id=" ",
                                     title="Message",
                                     msg="invalide creadential",
                                     duration="short"
                                     )
            toast.show()
            return render_template('user/login.html')
    elif request.method=='GET':
        return render_template('user/login.html')
    return render_template('user/index.html')

def voterdetails():
    if 'username' in session:
        userv= session['username']
        users=userm.userlist(userv)
        if request.method=='POST':
            voter_id= request.form['voter_id']
            user= userm.voter_id(userv,voter_id)
            if user:
                if user:
                    toast = Notification(app_id=" ",
                                            title="Message",
                                            msg="login successful",
                                            duration="short"
                                            )
                    toast.show()
                    return redirect(url_for('user.dashboard'))
                else:
                    toast = Notification(app_id=" ",
                                            title="Message",
                                            msg="invalide creadential",
                                            duration="short"
                                            )
                    toast.show()
                    return redirect(url_for('user.voterdetails'))
            else:
                userm.insertusercorrection(userv,voter_id)
                return redirect(url_for('user.voterdetails'))
        elif request.method=='GET':
            return render_template('user/voterdetails.html',users=users)
        else:
            render_template('user/voterdetails.html')
    return redirect(url_for('user.loginc'))
    

def dashboard():
    if 'username' in session:
        if request.method== 'POST':
            userv= session['username']
            party=request.form['party']
            users=userm.checkvoter(userv)
            if users:
                toast = Notification(app_id=" ",
                                     title="Message",
                                     msg="user already vote",
                                     duration="short"
                                     )
                toast.show()
                return render_template("user/dashboard.html", users=users)
            else:
                userm.insertvoter(userv,party)
                toast = Notification(app_id=" ",
                                     title="Message",
                                     msg="vote submit sucessfully",
                                     duration="short"
                                     )
                toast.show()
        return render_template('user/dashboard.html')
    else:
        return redirect(url_for('user.loginc'))
    
def otpgenerater():
        if request.method=='POST':
            email = request.form['email']
            session['email']=email
            msg=EmailMessage()
            msg['Subject'] = 'OTP' 
            msg['from']= from_mail
            msg['To'] = email
            msg.set_content("your otp is "+str(otp))
            server.send_message(msg)
            return redirect(url_for('user.verified'))
        else:
            return render_template('user/otpgenerater.html')
        
def verified():
    if 'email' in session:
        if request.method=="POST":
            input_otp=request.form['otp']
            if input_otp==otp:
                return redirect(url_for('user.changepassword'))
            else:
                session.pop('email', None)
                print('invalide')
                redirect(url_for('user.otpgenerater'))
        return render_template("user/validate.html")
    else:
        return redirect(url_for('user.otpgenerater'))

def changepassword():
    if 'email' in session:
        if request.method=="POST":
            email=session['email']
            password=request.form['password']
            userm.updatepassword(email,password)
            session.pop('email', None)
            return redirect(url_for('user.loginc'))
        elif request.method=="GET":
            return render_template("user/changepassword.html")
        return render_template("user/changepassword.html")
    else:
        return redirect(url_for('user.otpgenerater'))


def get_image(user_id):
    image_data = userm.get_user_photo(user_id)
    if image_data:
        return send_file(BytesIO(image_data), mimetype="image/jpeg")
    return "Image not found", 404

def logout():
    session.pop('username', None)
    return redirect(url_for('user.index'))
