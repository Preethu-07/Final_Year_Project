from bson import ObjectId
from pymongo import MongoClient

client = MongoClient('localhost', 27017)
db = client.voting_system
item_collection=db['user']

def result():
    return db.vote.aggregate([{'$group': {'_id': '$party', 'count': {'$sum': 1}}}])

def deleteuser(user):
    return item_collection.delete_one({"username":user})

def checkuser(phone):
    return db.user.find_one({'phonenumber':phone})

def checkvoter_Id(phone,verify):
    return db.user.find_one({'phonenumber':phone,'verifycation':verify})

def updateuser(phone,voter_id,verify):
    return db.user.update_one({'phonenumber':phone},{'$set':{'voter_id':voter_id,'verifycation':verify}})

def check_voter_id():
    return item_collection.find({'voter_msg':{'$ne':None}})

def update_user(user,address,state,email,phonenumber):
    item_collection.update_one({'username':user},{'$set':{'voter_msg':None}})
    return db.user.update_one({'username':user},{'$set':{'username':user,'Address':address,'state':state,'email':email,'phonenumber':phonenumber}})

def getUsers():
    return db.user.find()