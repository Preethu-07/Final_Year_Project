from bson import ObjectId
import gridfs
from pymongo import MongoClient

client = MongoClient('localhost', 27017)
db = client.voting_system
fs = gridfs.GridFS(db)
item_collection=db['user']

def checkuser(username):
    user=db.user.find_one({'username': username})
    return user

def insertuser(username ,Address,state,photo_binary,email,phonenumber, password):
    db.user.insert_one({'username': username, 'Address':Address, 'state':state, 'photo':photo_binary, 'email':email, 'phonenumber':phonenumber, 'password':password})

def checklogin(username, password):
    return db.user.find_one({'username': username, 'password': password})

def checkvoter(userv):
    return db.vote.find_one({'username':userv})

def insertvoter(userv , party):
    db.vote.insert_one({'username':userv, 'party':party})

def userlist(userv):
    return db.user.find_one({'username':userv})

def get_user_photo(user_id):
    user = db.user.find_one({"_id": ObjectId(user_id)})
    return user.get("photo") if user else None

def voter_id(useri, voter_id):
    return db.user.find_one({'username': useri,'voter_id':voter_id})

def insertusercorrection(userv,voter_id):
    return db.user.update_one({'username':userv},{'$set':{'voter_msg':voter_id}})

def updatepassword(email,password):
    return db.user.update_one({'email':email},{'$set':{'password':password}})





    