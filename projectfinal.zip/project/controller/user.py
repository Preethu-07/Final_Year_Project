from flask import Blueprint
from view import userv, adminv
from flask_login import login_required
router=Blueprint('user',__name__)


@router.route('/')
def index():
    return userv.index()

@router.route('/aboutUs' , methods=['GET' , 'POST'])
def aboutUs():
    return userv.aboutUs()

@router.route('/register' , methods=['GET' , 'POST'])
def register():
    return userv.register()

@router.route('/login',methods=['GET' , 'POST'])
def loginc():
    return userv.loginr()

@router.route("/get_image/<user_id>")
def get_image(user_id):  # Match the function name here
    return userv.get_image(user_id)



@router.route('/voterdetails', methods = ['GET' , 'POST'])
def  voterdetails():
    return userv.voterdetails()

@router.route('/dashboard', methods = ['GET' , 'POST'])
def dashboard():
    return userv.dashboard()

@router.route('/logout')
def logout():
    return userv.logout()

@router.route('/logina' , methods=['GET' , 'POST'])
def login():
    return adminv.login()

@router.route('/home')
def admin():
    return adminv.adminhome()

@router.route('/users', methods=['GET' , 'POST'])
def users():
    return adminv.users()

@router.route('/result')
def result():
    return adminv.result()

@router.route('/otpgenerater', methods=['GET' , 'POST'])
def otpgenerater():
    return userv.otpgenerater()

@router.route('/verified', methods=['GET','POST'])
def verified():
    return userv.verified()

@router.route('/changepassword', methods=['GET','POST'])
def changepassword():
    return userv.changepassword()

@router.route('/logouta')
def logoutadmin():
    return adminv.logouta()

@router.route('/correction', methods=['GET' , 'POST'])
def correction():
    return adminv.correction()
